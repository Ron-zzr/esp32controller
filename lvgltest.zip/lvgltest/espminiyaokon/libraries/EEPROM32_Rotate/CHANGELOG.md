# EEPROM32_Rotate change log

The format is based on [Keep a Changelog](http://keepachangelog.com/)
and this project adheres to [Semantic Versioning](http://semver.org/).

## [0.9.5] 2023-11-18
### Fix
- Fix missing definition of _user_defined_size

## [0.9.4] 2019-09-23
### Fix
- Added required header
- Removed unused variable
- Force SDK 1.0.2 in examples

## [0.9.3] 2019-02-12
### Fix
- Fix missing parens to support ESP-IDF under gcc 5.2.0

## [0.9.2] 2018-12-09
### Fix
- Fix magic number check around split (thanks to @arihantdaga and @mcspr)

## [0.9.0] 2018-06-03
- Initial working version
